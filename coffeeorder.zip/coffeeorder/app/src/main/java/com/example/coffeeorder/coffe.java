package com.example.coffeeorder;

public class coffe {
    private String Coffeename;
    private  String Price;

    public coffe(String coffeename, String price) {
        Coffeename = coffeename;
        Price = price;
    }

    public String getCoffeename() {
        return Coffeename;
    }

    public String getPrice() {
        return Price;
    }

    public void setCoffeename(String coffeename) {
        Coffeename = coffeename;
    }

    public void setPrice(String price) {
        Price = price;
    }
}
