package com.example.coffeeorder;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener, CompoundButton.OnCheckedChangeListener, View.OnClickListener {
    Spinner sp;
    TextView price;
    RadioButton s1,m1,l1;
    Button btn;
    CheckBox cb1,cb2,cb3;

    ArrayList<coffe> list = new ArrayList<coffe>();
    ArrayList<String> name  = new ArrayList<>();
    public  static double total = 0;
    public  static double  tprice = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        price = findViewById(R.id.pri);
        sp = findViewById(R.id.spinner);
        s1 =findViewById(R.id.radioButton);
        m1 = findViewById(R.id.radioButton4);
        l1 = findViewById(R.id.radioButton6);
        btn = findViewById(R.id.cal);
        cb1= findViewById(R.id.checkBox);
        cb2 = findViewById(R.id.checkBox2);
        cb3 = findViewById(R.id.checkBox3);
        btn.setOnClickListener(this);
        s1.setOnClickListener(this);
        m1.setOnClickListener(this);
        l1.setOnClickListener(this);
        sp.setOnItemSelectedListener(this);
        filldata();
        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line,name);
        sp.setAdapter(aa);
        price.setText("0");

    }

    public void filldata(){
        list.add(new coffe("Coffee","1.7"));
        list.add(new coffe("Hot Chocolate","1.3"));
        list.add(new coffe("Cappuccino","2.2"));
        list.add(new coffe("Espresso","0.9"));
        for (int i = 0;i<list.size();i++) {
            name.add(list.get(i).getCoffeename());
        }


    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        total = Double.parseDouble(list.get(position).getPrice());
         //price.setText(list.get(position).getPrice());
        tprice = total;
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

        }


    @Override
    public void onClick(View v) {
        total = tprice;
        if(s1.isChecked())
            total += 0;
        else if(m1.isChecked())
            total *= 1.5;
        else if(l1.isChecked())
            total *= 2;
        if(cb1.isChecked())
            total += 0.5;
        if(cb2.isChecked())
            total += 0;
        if(cb3.isChecked())
            total += 0.25;
        total = total * 1.13;

        price.setText(String.format("%.2f",total));
        //Toast.makeText(getApplicationContext(),"THanks for order",Toast.LENGTH_LONG).show();
    }
}

